package simpledb.index.ehash;

import java.util.ArrayList;
import simpledb.tx.Transaction;
import simpledb.record.*;
import simpledb.query.*;
import simpledb.index.Index;

/*
 * CS4432 Project 2: 
 * Bucket class to hold data for each bucket
 * Contains bucket number, size of the bucket and the local depth for each bucket
 */

public class Bucket {
	private int localDepth;
	private int bucketNum;
	private int size;
	private ArrayList<Integer> contents = new ArrayList<Integer>();
	
	public Bucket(int local, int num) {
		localDepth = local;
		bucketNum = num;
		size = 0;
	}
	
	/*
	 * CS4432 Project 2: 
	 * returns how many items are in bucket
	 */
	public int getSize() {
		return size;
	}
	
	/*
	 * CS4432 Project 2: 
	 * returns local depth of bucket
	 */
	public int getLocalDepth() {
		return localDepth;
	}
	
	/*
	 * CS4432 Project 2: 
	 * increments the bucket local depth
	 */
	public void incrementLD() {
		localDepth++;
	}
	
	/*
	 * CS4432 Project 2: 
	 * adds val to ArrayList of contents within Bucket
	 */
	public void addToContents(Integer val) {
		contents.add(val);
		size++;
	}
}

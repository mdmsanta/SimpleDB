package simpledb.index.ehash;

import simpledb.tx.Transaction;
import simpledb.record.*;
import simpledb.query.*;
import simpledb.index.Index;

import java.util.HashMap;

/**
 * A static hash implementation of the Index interface.
 * A fixed number of buckets is allocated (currently, 100),
 * and each bucket is implemented as a file of index records.
 * @author Edward Sciore
 */
public class eHashIndex implements Index {
	public static int NUM_BUCKETS = 4;
	public static int MAX_BUCKET = 8;
	private String idxname;
	private Schema sch;
	private Transaction tx;
	private Constant searchkey = null;
	private TableScan ts = null;
	int globalDepth;
	private static HashMap<Integer,Bucket> map = new HashMap<Integer,Bucket>();

	/**
	 * Opens a hash index for the specified index.
	 * @param idxname the name of the index
	 * @param sch the schema of the index records
	 * @param tx the calling transaction
	 */
	/*
	 * CS4432 Project 2: 
	 * Initializes the global depth to 2 and initializes four buckets
	 */
	public eHashIndex(String idxname, Schema sch, Transaction tx) {
		this.idxname = idxname;
		this.sch = sch;
		this.tx = tx;
		globalDepth = 2;
		map.put(00, new Bucket(2,1));
		map.put(01, new Bucket(2,2));
		map.put(10, new Bucket(2,3));
		map.put(11, new Bucket(2,4));
	}

	/**
	 * Positions the index before the first index record
	 * having the specified search key.
	 * The method hashes the search key to determine the bucket,
	 * and then opens a table scan on the file
	 * corresponding to the bucket.
	 * The table scan for the previous bucket (if any) is closed.
	 * @see simpledb.index.Index#beforeFirst(simpledb.query.Constant)
	 */
	/*
	 * CS4432 Project 2: 
	 * Gets the bitMask and uses it to find correct bucket
	 * Calls hashToBucket in order to add the searchkey to the correct bucket
	 */
	public void beforeFirst(Constant searchkey) {
		close();
		this.searchkey = searchkey;
		int bitMask = getBitMask(2);
		int bucket = searchkey.hashCode() % NUM_BUCKETS;
		hashToBucket(bucket,bitMask);
	}
	
	/*
	 * CS4432 Project 2: 
	 * If the size of the bucket is too big (equal to the Max bucket size) then the bucket has to be split
	 * If the global depth is less than the local depth after the local depth is incremented, then the global
	 * depth has to be incremented
	 * else the searchkey can be added to the bucket
	 */
	public void hashToBucket(int bucket, int bitMask) {
		Bucket b = map.get(bitMask);
		if(b.getSize() == MAX_BUCKET) {
			b.incrementLD();
			if(b.getLocalDepth() > globalDepth) {
				incrementGlobalDepth(b.getLocalDepth());
			}else {
				split(b);
			}
		}else {
			map.get(bitMask).addToContents(searchkey.hashCode());
			String tblname = idxname + bitMask;
			TableInfo ti = new TableInfo(tblname, sch);
			ts = new TableScan(ti, tx);
		}
	}
	
	/*
	 * CS4432 Project 2: 
	 * Split bucket function, there wasn't enough time to complete this function
	 * This function would have made another bucket and split the current items in the old bucket among the 
	 * two buckets
	 */
	public void split(Bucket b) {
		
	}
	
	/*
	 * CS4432 Project 2: 
	 * Increments the global depth, there wasn't enough time to complete this function
	 * This function would have made the global depth equal to the local depth that was higher than the old global depth
	 * This would have doubled the number of buckets and the items in the buckets would need to be redistributed 
	 * among the new buckets
	 */
	public void incrementGlobalDepth(int depth) {
		globalDepth = depth;
	}
	
	/*
	 * CS4432 - gets BitMask to return the right bucket
	 */
	public int getBitMask(int depth) {
		int bitMask = 1;
		for(int x = 1;x < depth;x++) {
			bitMask = bitMask << 1;
		}
		return bitMask;	
	}

	/**
	 * Moves to the next record having the search key.
	 * The method loops through the table scan for the bucket,
	 * looking for a matching record, and returning false
	 * if there are no more such records.
	 * @see simpledb.index.Index#next()
	 */
	public boolean next() {
		while (ts.next())
			if (ts.getVal("dataval").equals(searchkey))
				return true;
		return false;
	}

	/**
	 * Retrieves the dataRID from the current record
	 * in the table scan for the bucket.
	 * @see simpledb.index.Index#getDataRid()
	 */
	public RID getDataRid() {
		int blknum = ts.getInt("block");
		int id = ts.getInt("id");
		return new RID(blknum, id);
	}

	/**
	 * Inserts a new record into the table scan for the bucket.
	 * @see simpledb.index.Index#insert(simpledb.query.Constant, simpledb.record.RID)
	 */
	public void insert(Constant val, RID rid) {
		beforeFirst(val);
		ts.insert();
		ts.setInt("block", rid.blockNumber());
		ts.setInt("id", rid.id());
		ts.setVal("dataval", val);
	}

	/**
	 * Deletes the specified record from the table scan for
	 * the bucket.  The method starts at the beginning of the
	 * scan, and loops through the records until the
	 * specified record is found.
	 * @see simpledb.index.Index#delete(simpledb.query.Constant, simpledb.record.RID)
	 */
	public void delete(Constant val, RID rid) {
		beforeFirst(val);
		while(next())
			if (getDataRid().equals(rid)) {
				ts.delete();
				return;
			}
	}

	/**
	 * Closes the index by closing the current table scan.
	 * @see simpledb.index.Index#close()
	 */
	public void close() {
		if (ts != null)
			ts.close();
	}

	/**
	 * Returns the cost of searching an index file having the
	 * specified number of blocks.
	 * The method assumes that all buckets are about the
	 * same size, and so the cost is simply the size of
	 * the bucket.
	 * @param numblocks the number of blocks of index records
	 * @param rpb the number of records per block (not used here)
	 * @return the cost of traversing the index
	 */
	public static int searchCost(int numblocks, int rpb){
		return numblocks / eHashIndex.NUM_BUCKETS;
	}
}
